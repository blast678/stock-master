import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiPlus, FiEye, FiUpload } from 'react-icons/fi';
import { format } from 'date-fns';
import MainLayout from '../layouts/MainLayout';
import { deliveryService } from '../services/deliveryService';
import './Delivery.css';

const Delivery = () => {
  const navigate = useNavigate();
  const [deliveries, setDeliveries] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDeliveries();
  }, []);

  const fetchDeliveries = async () => {
    setLoading(true);
    try {
      const response = await deliveryService.getAll();
      setDeliveries(response.data);
    } catch (error) {
      console.error('Failed to fetch deliveries:', error);
      alert('Failed to load deliveries');
    } finally {
      setLoading(false);
    }
  };

  const filteredDeliveries = filter === 'all' 
    ? deliveries 
    : deliveries.filter(d => d.status.toLowerCase() === filter);

  return (
    <MainLayout>
      <div className="delivery-page">
        <div className="page-header">
          <div className="header-left">
            <FiUpload size={32} />
            <h1>Delivery (Outgoing Stock)</h1>
          </div>
          <button className="btn btn-primary" onClick={() => navigate('/delivery/new')}>
            <FiPlus /> New Delivery
          </button>
        </div>

        <div className="filter-tabs">
          <button className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>
            All
          </button>
          <button className={filter === 'draft' ? 'active' : ''} onClick={() => setFilter('draft')}>
            Draft
          </button>
          <button className={filter === 'waiting' ? 'active' : ''} onClick={() => setFilter('waiting')}>
            Waiting
          </button>
          <button className={filter === 'ready' ? 'active' : ''} onClick={() => setFilter('ready')}>
            Ready
          </button>
          <button className={filter === 'done' ? 'active' : ''} onClick={() => setFilter('done')}>
            Done
          </button>
        </div>

        {loading ? (
          <div className="loading">Loading deliveries...</div>
        ) : (
          <div className="delivery-grid">
            {filteredDeliveries.length === 0 ? (
              <p style={{textAlign: 'center', color: 'var(--text-secondary)', padding: '2rem'}}>
                No deliveries found
              </p>
            ) : (
              filteredDeliveries.map(delivery => (
                <div key={delivery._id} className="delivery-card">
                  <div className="card-header">
                    <h3>{delivery.reference}</h3>
                    <span className={`status-badge status-${delivery.status.toLowerCase()}`}>
                      {delivery.status}
                    </span>
                  </div>
                  <div className="card-body">
                    <p><strong>Customer:</strong> {delivery.to}</p>
                    <p><strong>Schedule:</strong> {format(new Date(delivery.scheduleDate), 'MMM dd, yyyy')}</p>
                    <p><strong>Items:</strong> {delivery.products.length}</p>
                  </div>
                  <div className="card-actions">
                    <button className="btn btn-sm btn-secondary" onClick={() => navigate(`/delivery/${delivery._id}`)}>
                      <FiEye /> View
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
};

export default Delivery;
